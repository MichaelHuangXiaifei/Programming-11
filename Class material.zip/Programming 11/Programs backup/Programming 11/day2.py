#Types
print(type("Hello, World"))
print(type(17))
print(type(3.2))
print(type("17"))
print(type("3.2"))
print(type(2 < 3))
print(1,000,000)

#Variable
n = "I am a student"
n = "I am a teacher" #change value of a variable
print(n)

print("I" + " " + "am")