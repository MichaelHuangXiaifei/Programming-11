print("I am a student")
#The code above is to print the sentens "I am a student"
print((2 + 5) / 3 + 2)
print((2 + 5) % 3 + 2)

print(type("abc"),type(1),type(2.5),type(print),sep="\n")

a = 1
b = 2.5
c = "Hello"

#must begin with a letter，it is legal to use uppercase letters or numbers to start with,
# and Python”s keywords cannot be used as variable names.

print("1" + "2")

#✳叫星号star
##叫井号pound