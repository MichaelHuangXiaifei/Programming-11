#day 1 study code

print("Hello World")
print("Hello Again")
print("I like typing this.")
print("This is fun.")
print('Yay! Printing.')
print("I'd much rather you 'not'.") #note quotation marks
print('I "said" do not touch this.') #note quotation marks
print(100 - 25 * 3 % 4)

#after class
'''
+ does addition
- does subtract
/ does division
* does multiplication
% does modulo operation
<, >, <=, >= does judgment, return true or false
'''
#avreage time per mile
print(round(((43 / 60) + (30 / 60 / 60)) / (10 / 1.61),2),"hours per mile")
#average speed in miles per hour
print(round((10 / 1.61) / ((43 / 60) + (30 / 60 / 60)),2),"miles per hour")